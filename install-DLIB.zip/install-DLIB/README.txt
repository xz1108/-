1.put "dlib-19.7.0-cp36-cp36m-win_amd64.whl" into your computer.(PIC_1)
2.open command window, then into the route where you put "dlib-19.7.0-cp36-cp36m-win_amd64.whl".
3.finally, you need to input "pip install dlib-19.7.0-cp36-cp36m-win_amd64.whl"(PIC_2)
4.you can import dlib in pycharm.
